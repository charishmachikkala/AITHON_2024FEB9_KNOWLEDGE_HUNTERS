# Import necessary libraries
from flask import Flask, render_template, request
import pandas as pd
import random
import string
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

# Initialize Flask app
app = Flask(__name__)

# Download NLTK resources
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Load existing dummy data
existing_dummy_data = pd.read_csv("combined_dummy_data.csv")

# Convert existing data to DataFrame
df_existing = pd.DataFrame(existing_dummy_data)

# Add new dummy data
def generate_random_string(length):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for _ in range(length))

def generate_random_data():
    new_dummy_data = {
        'username': [generate_random_string(10) for _ in range(500)],
        'bio': [generate_random_string(20) for _ in range(500)],
        'followers': [random.randint(100, 1000) for _ in range(500)],
        'likes': [random.randint(10, 100) for _ in range(500)],
        'posts': [random.randint(10, 50) for _ in range(500)],
        'comments': [random.randint(1, 10) for _ in range(500)],
        'shares': [random.randint(1, 20) for _ in range(500)]
    }
    return new_dummy_data

new_dummy_data = generate_random_data()

# Convert new data to DataFrame
df_new = pd.DataFrame(new_dummy_data)

# Concatenate existing and new data
df_combined = pd.concat([df_existing, df_new], ignore_index=True)


# Function for text preprocessing
def preprocess_text(text):
    # Tokenization
    tokens = word_tokenize(text)
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [word for word in tokens if word.lower() not in stop_words]
    # Lemmatization
    lemmatizer = WordNetLemmatizer()
    lemmatized_tokens = [lemmatizer.lemmatize(word) for word in filtered_tokens]
    # Join tokens back into a single string
    preprocessed_text = ' '.join(lemmatized_tokens)
    return preprocessed_text

# Define weights for engagement metrics
weights = {'likes': 0.4, 'comments': 0.3, 'shares': 0.2, 'followers': 0.1}

# Function to calculate influence score
def calculate_influence_score(row):
    # Apply text preprocessing to bio
    preprocessed_bio = preprocess_text(row['bio'])
    # Calculate influence score
    return sum(row[metric] * weight for metric, weight in weights.items())

# Function to get top influencer in a specific domain
def get_top_influencer(domain, df):
    domain_influencers = df[df['bio'].str.contains(domain, case=False)]
    if domain_influencers.empty:
        return "No influencers found in the specified domain."

    domain_influencers.loc[:, 'influence_score'] = domain_influencers.apply(calculate_influence_score, axis=1)
    domain_influencers = domain_influencers.sort_values(by='influence_score', ascending=False)
    top_influencer = domain_influencers.iloc[0]
    return f"Top influencer in {domain}: Username - {top_influencer['username']}, Bio - {top_influencer['bio']}"

# Define route for index page and result display
@app.route('/')
def home():
    return render_template("home.html")

@app.route('/index', methods=['GET', 'POST'])

def index():
    domains = [
        'fashion', 'fitness', 'beauty', 'travel', 'food and cooking', 'parenting and family', 'technology and gadgets',
        'home decor and interior design', 'gaming', 'health and wellness', 'finance and investing', 'education and learning',
        'diy and crafts', 'music and entertainment', 'photography and art', 'sports and athletics', 'environmental conservation',
        'mental health and self-care', 'business and entrepreneurship', 'social activism and advocacy'
    ]

    if request.method == 'POST':
        domain_choice = request.form['domain']
        top_influencer = get_top_influencer(domain_choice.lower(), df_combined)  # Use combined DataFrame for training
        return render_template('index.html', domains=domains, top_influencer=top_influencer)
    else:
        return render_template('index.html', domains=domains)
# Run the Flask app
if __name__== '__main__':
    app.run(debug=True)